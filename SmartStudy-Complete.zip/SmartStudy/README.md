# SmartStudy – AI-Powered Student Life & Study Management System

A complete college-project starter with:
- Flask backend
- SQLite database
- Responsive HTML/CSS/JavaScript frontend
- Login/register
- Dashboard
- Subjects
- Tasks / practicals
- Exams
- Attendance
- Study-session tracking
- Profile photo
- AI Study Assistant API
- JSON statistics API

## 1. Requirements
Python 3.10+ recommended.

## 2. Install
Open PowerShell in this folder:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If PowerShell blocks activation, use:
```powershell
venv\Scripts\activate.bat
```

## 3. Run
```powershell
python app.py
```

Open:
http://127.0.0.1:5000

The SQLite database `smartstudy.db` is created automatically.

## 4. First use
Create an account, then add subjects. After that add tasks, exams, attendance and study sessions.

## 5. Project structure

SmartStudy/
├── app.py
├── requirements.txt
├── README.md
├── smartstudy.db          # created automatically after first run
├── templates/
│   ├── base.html
│   ├── landing.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── subjects.html
│   ├── tasks.html
│   ├── exams.html
│   ├── attendance.html
│   ├── study.html
│   └── profile.html
└── static/
    ├── style.css
    ├── app.js
    └── uploads/

## AI
The included `/api/ai` endpoint works with a built-in educational fallback, so the project runs without an API key.

For a production AI integration, connect the endpoint to the AI provider/API you are authorized to use and keep the key in an environment variable. Never put API keys in HTML or JavaScript.

## Database tables
users, subjects, tasks, exams, attendance, study_sessions
