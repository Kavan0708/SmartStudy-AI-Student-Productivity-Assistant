from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, date
import sqlite3, os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "smartstudy-dev-secret")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "smartstudy.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        photo TEXT DEFAULT '',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        code TEXT DEFAULT '',
        color TEXT DEFAULT '#6366f1',
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject_id INTEGER,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        due_date TEXT,
        priority TEXT DEFAULT 'Medium',
        status TEXT DEFAULT 'Pending',
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject_id INTEGER,
        title TEXT NOT NULL,
        exam_date TEXT NOT NULL,
        notes TEXT DEFAULT '',
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        attended INTEGER DEFAULT 0,
        total INTEGER DEFAULT 0,
        UNIQUE(user_id, subject_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS study_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        subject_id INTEGER,
        session_date TEXT NOT NULL,
        minutes INTEGER NOT NULL,
        notes TEXT DEFAULT '',
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE SET NULL
    );
    """)
    conn.commit()
    conn.close()

def login_required():
    return "user_id" in session

def current_user():
    if not login_required():
        return None
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return user

@app.context_processor
def inject_user():
    return {"current_user": current_user(), "today": date.today().isoformat()}

@app.route("/")
def index():
    if login_required():
        return redirect(url_for("dashboard"))
    return render_template("landing.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        if not name or not email or len(password) < 6:
            flash("Enter your name, valid email and a password of at least 6 characters.", "error")
            return render_template("register.html")
        conn = db()
        try:
            conn.execute(
                "INSERT INTO users(name,email,password,created_at) VALUES(?,?,?,?)",
                (name, email, generate_password_hash(password), datetime.now().isoformat())
            )
            conn.commit()
            user = conn.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
            session["user_id"] = user["id"]
            flash("Welcome to SmartStudy!", "success")
            return redirect(url_for("dashboard"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.", "error")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    if not login_required(): return redirect(url_for("login"))
    uid = session["user_id"]
    conn = db()
    subjects = conn.execute("SELECT * FROM subjects WHERE user_id=? ORDER BY id DESC", (uid,)).fetchall()
    tasks = conn.execute("""
        SELECT tasks.*, subjects.name subject_name FROM tasks
        LEFT JOIN subjects ON subjects.id=tasks.subject_id
        WHERE tasks.user_id=? ORDER BY
        CASE status WHEN 'Pending' THEN 0 ELSE 1 END,
        due_date IS NULL, due_date, id DESC LIMIT 8
    """, (uid,)).fetchall()
    exams = conn.execute("""
        SELECT exams.*, subjects.name subject_name FROM exams
        LEFT JOIN subjects ON subjects.id=exams.subject_id
        WHERE exams.user_id=? ORDER BY exam_date LIMIT 5
    """, (uid,)).fetchall()
    total_tasks = conn.execute("SELECT COUNT(*) c FROM tasks WHERE user_id=?", (uid,)).fetchone()["c"]
    done_tasks = conn.execute("SELECT COUNT(*) c FROM tasks WHERE user_id=? AND status='Completed'", (uid,)).fetchone()["c"]
    study_minutes = conn.execute("SELECT COALESCE(SUM(minutes),0) m FROM study_sessions WHERE user_id=?", (uid,)).fetchone()["m"]
    conn.close()
    return render_template("dashboard.html", subjects=subjects, tasks=tasks, exams=exams,
                           total_tasks=total_tasks, done_tasks=done_tasks,
                           study_minutes=study_minutes)

@app.route("/subjects", methods=["GET", "POST"])
def subjects():
    if not login_required(): return redirect(url_for("login"))
    uid = session["user_id"]
    conn = db()
    if request.method == "POST":
        name = request.form["name"].strip()
        code = request.form.get("code","").strip()
        color = request.form.get("color","#6366f1")
        if name:
            conn.execute("INSERT INTO subjects(user_id,name,code,color) VALUES(?,?,?,?)",(uid,name,code,color))
            conn.commit()
            flash("Subject added.", "success")
        return redirect(url_for("subjects"))
    rows = conn.execute("""
        SELECT s.*, COALESCE(a.attended,0) attended, COALESCE(a.total,0) total
        FROM subjects s LEFT JOIN attendance a ON a.subject_id=s.id AND a.user_id=s.user_id
        WHERE s.user_id=? ORDER BY s.id DESC
    """,(uid,)).fetchall()
    conn.close()
    return render_template("subjects.html", subjects=rows)

@app.post("/subjects/delete/<int:sid>")
def delete_subject(sid):
    if not login_required(): return redirect(url_for("login"))
    conn=db()
    conn.execute("DELETE FROM subjects WHERE id=? AND user_id=?",(sid,session["user_id"]))
    conn.commit(); conn.close()
    return redirect(url_for("subjects"))

@app.route("/tasks", methods=["GET","POST"])
def tasks():
    if not login_required(): return redirect(url_for("login"))
    uid=session["user_id"]; conn=db()
    if request.method=="POST":
        conn.execute("""INSERT INTO tasks(user_id,subject_id,title,description,due_date,priority,status,created_at)
        VALUES(?,?,?,?,?,?,?,?)""",(uid,request.form.get("subject_id") or None,
        request.form["title"].strip(),request.form.get("description","").strip(),
        request.form.get("due_date") or None,request.form.get("priority","Medium"),
        "Pending",datetime.now().isoformat()))
        conn.commit(); conn.close()
        flash("Task created.","success"); return redirect(url_for("tasks"))
    rows=conn.execute("""SELECT tasks.*,subjects.name subject_name FROM tasks
        LEFT JOIN subjects ON subjects.id=tasks.subject_id WHERE tasks.user_id=?
        ORDER BY status='Completed', due_date IS NULL, due_date DESC""",(uid,)).fetchall()
    subs=conn.execute("SELECT * FROM subjects WHERE user_id=? ORDER BY name",(uid,)).fetchall()
    conn.close()
    return render_template("tasks.html",tasks=rows,subjects=subs)

@app.post("/tasks/toggle/<int:tid>")
def toggle_task(tid):
    if not login_required(): return redirect(url_for("login"))
    conn=db()
    row=conn.execute("SELECT status FROM tasks WHERE id=? AND user_id=?",(tid,session["user_id"])).fetchone()
    if row:
        new="Completed" if row["status"]!="Completed" else "Pending"
        conn.execute("UPDATE tasks SET status=? WHERE id=? AND user_id=?",(new,tid,session["user_id"]))
        conn.commit()
    conn.close(); return redirect(request.referrer or url_for("tasks"))

@app.post("/tasks/delete/<int:tid>")
def delete_task(tid):
    if not login_required(): return redirect(url_for("login"))
    conn=db(); conn.execute("DELETE FROM tasks WHERE id=? AND user_id=?",(tid,session["user_id"]))
    conn.commit(); conn.close(); return redirect(url_for("tasks"))

@app.route("/exams", methods=["GET","POST"])
def exams():
    if not login_required(): return redirect(url_for("login"))
    uid=session["user_id"]; conn=db()
    if request.method=="POST":
        conn.execute("INSERT INTO exams(user_id,subject_id,title,exam_date,notes) VALUES(?,?,?,?,?)",
                     (uid,request.form.get("subject_id") or None,request.form["title"],
                      request.form["exam_date"],request.form.get("notes","")))
        conn.commit(); flash("Exam added.","success"); return redirect(url_for("exams"))
    rows=conn.execute("""SELECT exams.*,subjects.name subject_name FROM exams
        LEFT JOIN subjects ON subjects.id=exams.subject_id WHERE exams.user_id=? ORDER BY exam_date""",(uid,)).fetchall()
    subs=conn.execute("SELECT * FROM subjects WHERE user_id=? ORDER BY name",(uid,)).fetchall()
    conn.close(); return render_template("exams.html",exams=rows,subjects=subs)

@app.post("/exams/delete/<int:eid>")
def delete_exam(eid):
    if not login_required(): return redirect(url_for("login"))
    conn=db(); conn.execute("DELETE FROM exams WHERE id=? AND user_id=?",(eid,session["user_id"]))
    conn.commit(); conn.close(); return redirect(url_for("exams"))

@app.route("/attendance", methods=["GET","POST"])
def attendance():
    if not login_required(): return redirect(url_for("login"))
    uid=session["user_id"]; conn=db()
    if request.method=="POST":
        sid=int(request.form["subject_id"]); attended=max(0,int(request.form["attended"])); total=max(attended,int(request.form["total"]))
        conn.execute("""INSERT INTO attendance(user_id,subject_id,attended,total) VALUES(?,?,?,?)
        ON CONFLICT(user_id,subject_id) DO UPDATE SET attended=excluded.attended,total=excluded.total""",(uid,sid,attended,total))
        conn.commit(); flash("Attendance updated.","success")
    rows=conn.execute("""SELECT s.*,COALESCE(a.attended,0) attended,COALESCE(a.total,0) total
        FROM subjects s LEFT JOIN attendance a ON a.subject_id=s.id AND a.user_id=s.user_id
        WHERE s.user_id=? ORDER BY s.name""",(uid,)).fetchall()
    conn.close(); return render_template("attendance.html",subjects=rows)

@app.route("/study", methods=["GET","POST"])
def study():
    if not login_required(): return redirect(url_for("login"))
    uid=session["user_id"]; conn=db()
    if request.method=="POST":
        conn.execute("""INSERT INTO study_sessions(user_id,subject_id,session_date,minutes,notes)
        VALUES(?,?,?,?,?)""",(uid,request.form.get("subject_id") or None,
        request.form["session_date"],int(request.form["minutes"]),request.form.get("notes","")))
        conn.commit(); flash("Study session saved.","success")
    rows=conn.execute("""SELECT study_sessions.*,subjects.name subject_name FROM study_sessions
        LEFT JOIN subjects ON subjects.id=study_sessions.subject_id WHERE study_sessions.user_id=?
        ORDER BY session_date DESC,id DESC LIMIT 20""",(uid,)).fetchall()
    subs=conn.execute("SELECT * FROM subjects WHERE user_id=? ORDER BY name",(uid,)).fetchall()
    total=conn.execute("SELECT COALESCE(SUM(minutes),0)m FROM study_sessions WHERE user_id=?",(uid,)).fetchone()["m"]
    conn.close(); return render_template("study.html",sessions=rows,subjects=subs,total=total)

@app.route("/profile", methods=["GET","POST"])
def profile():
    if not login_required(): return redirect(url_for("login"))
    uid=session["user_id"]; conn=db()
    if request.method=="POST":
        name=request.form["name"].strip()
        photo=current_user()["photo"]
        file=request.files.get("photo")
        if file and file.filename:
            ext=os.path.splitext(secure_filename(file.filename))[1].lower()
            if ext in [".jpg",".jpeg",".png",".webp"]:
                fname=f"user_{uid}{ext}"
                file.save(os.path.join(UPLOAD_DIR,fname)); photo=fname
        conn.execute("UPDATE users SET name=?,photo=? WHERE id=?",(name,photo,uid))
        conn.commit(); flash("Profile updated.","success")
    user=conn.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
    conn.close(); return render_template("profile.html",user=user)

@app.route("/api/ai", methods=["POST"])
def ai():
    if not login_required(): return jsonify({"error":"Login required"}),401
    data=request.get_json(silent=True) or {}
    q=(data.get("message") or "").strip().lower()
    if not q: return jsonify({"answer":"Ask me a study question."})
    answers=[
        ("schedule", "Try the 50/10 method: study for 50 minutes, take a 10-minute break, and repeat. Put your hardest subject in your highest-energy time."),
        ("python", "For Python, start with variables → input/output → if/else → loops → functions → lists/dictionaries → files → OOP. Practice one small program after each topic."),
        ("database", "A database stores organized data. In SQLite, tables contain rows and columns. A primary key uniquely identifies each row, while foreign keys connect related tables."),
        ("exam", "For an exam, split the syllabus into small topics, revise actively, solve questions without looking at notes, and keep the last session for quick revision."),
        ("attendance", "Attendance percentage = (classes attended ÷ total classes) × 100. Update your attendance after each class so the dashboard stays accurate."),
        ("time", "Make a short priority list: 1 urgent academic task, 1 important long-term task, and 1 revision task. Avoid putting more than 3 major tasks in one day.")
    ]
    for key,ans in answers:
        if key in q: return jsonify({"answer":ans})
    return jsonify({"answer":"I can help with study plans, Python, databases, exams, attendance and time management. For deeper AI answers, add an AI API key in your environment and connect your preferred provider to this endpoint."})

@app.route("/api/stats")
def stats():
    if not login_required(): return jsonify({"error":"Login required"}),401
    uid=session["user_id"]; conn=db()
    data=conn.execute("""SELECT s.name,COALESCE(SUM(ss.minutes),0) minutes
        FROM subjects s LEFT JOIN study_sessions ss ON ss.subject_id=s.id AND ss.user_id=?
        WHERE s.user_id=? GROUP BY s.id ORDER BY minutes DESC""",(uid,uid)).fetchall()
    conn.close(); return jsonify([dict(x) for x in data])

if __name__=="__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
