function openAI(){document.getElementById("aiModal").classList.add("show");setTimeout(()=>document.getElementById("aiInput")?.focus(),100)}
function closeAI(){document.getElementById("aiModal").classList.remove("show")}
async function sendAI(e){
 e.preventDefault(); const input=document.getElementById("aiInput"), chat=document.getElementById("chat");
 const msg=input.value.trim(); if(!msg)return;
 chat.innerHTML += `<div class="bubble user">${escapeHtml(msg)}</div>`; input.value="";
 chat.innerHTML += `<div class="bubble bot" id="typing">Thinking…</div>`; chat.scrollTop=chat.scrollHeight;
 try{
  const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:msg})});
  const d=await r.json(); document.getElementById("typing").outerHTML=`<div class="bubble bot">${escapeHtml(d.answer||"Sorry, I couldn't answer that.")}</div>`;
 }catch(err){document.getElementById("typing").outerHTML=`<div class="bubble bot">Something went wrong. Please try again.</div>`}
 chat.scrollTop=chat.scrollHeight;
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]))}
function editAttendance(id,name,a,t){
 document.getElementById("attSubject").value=id; document.getElementById("attAttended").value=a; document.getElementById("attTotal").value=t;
 document.querySelector(".narrow")?.scrollIntoView({behavior:"smooth",block:"center"});
}
document.addEventListener("click",e=>{if(e.target.id==="aiModal")closeAI()});
setTimeout(()=>document.querySelectorAll(".flash").forEach(x=>x.remove()),4000);
